# BizLens 📊

**Business analytics, statistical inference, and process mining — all in one package**

BizLens is a Python library for business analysts, data scientists, educators, and students. It delivers professional statistical analysis, beautiful Rich tables, and built-in support for business process mining — all with a single `pip install`.

---

## 🚀 Open in Google Colab — No Installation Needed

Click any link to launch a notebook instantly in your browser:

### Core Analytics

| Notebook | Colab Link | What You'll Learn |
|----------|-----------|-------------------|
| **Quick Start** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New_Quick_Start_bizlens.ipynb) | Full tour: tables, quality, inference, process mining |
| **Descriptive Analytics** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New_Descriptive_Analytics.ipynb) | Frequency, percentile, contingency, data profile |
| **Statistical Inference** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New_Statistica_Inference.ipynb) | Confidence intervals, t-tests, ANOVA, correlation |
| **Chi-Square & Association** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New_ChiSquareTest.ipynb) | Chi-square, contingency tables, Cramér's V |
| **Probability & Distributions** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New_Probability_Distribution_Simulation.ipynb) | Distribution fitting, simulation, CLT, sampling |

### Machine Learning

| Notebook | Colab Link | What You'll Learn |
|----------|-----------|-------------------|
| **Linear & Multiple Regression** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New_Linear_Multiple_Linear_Regression.ipynb) | OLS regression, diagnostics, R², predictions |
| **Logistic Regression** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New_Logistics_Regression.ipynb) | Binary classification, odds ratios, ROC, AUC |
| **Decision Trees & Random Forests** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New_Decision_Trees_Random_Forests.ipynb) | Tree models, feature importance, ensembles |
| **PCA & Clustering** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New_PCA_Clustering.ipynb) | Dimensionality reduction, K-Means, DBSCAN |
| **Conjoint Analysis** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New_Conjoint_Analysis.ipynb) | Preference modelling, part-worth utilities, attribute importance |
| **Q-Learning** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New_Q_Learning.ipynb) | Reinforcement learning, Q-table, epsilon-greedy |

### Process Mining

| Notebook | Colab Link | What You'll Learn |
|----------|-----------|-------------------|
| **Process Mining** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New_Process_Mining.ipynb) | Case metrics, bottlenecks, variants, resources |
| **Process Mining (Advanced)** | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/solutiongate-learn/bizlens/blob/main/notebooks/New2_Process_Mining.ipynb) | Transition matrix, Sankey flow, timeline visualisation |

> All notebooks auto-install BizLens on first run — just click the Colab badge and run the first cell.

---

## 💾 Installation

```bash
pip install bizlens
```

```bash
# Upgrade to latest
pip install --upgrade bizlens
```

```bash
# Latest from source
git clone https://github.com/solutiongate-learn/bizlens.git
cd bizlens && pip install -e .
```

---

## 📦 Modules at a Glance

| Module | Key Functions |
|--------|--------------|
| `bl.tables` | `frequency_table`, `percentile_table`, `contingency_table`, `summary_statistics`, `group_comparison`, `distribution_fit` |
| `bl.diagnostic` | `detect_outliers`, `normality_test`, `correlation_analysis`, `missing_value_analysis`, `sample_vs_population` |
| `bl.inference` | `confidence_interval`, `two_sample_ttest`, `one_sample_ttest`, `anova_test`, `paired_ttest`, `correlation_test`, `effect_size_interpreter` |
| `bl.process_mining` | `case_metrics`, `activity_metrics`, `variant_discovery`, `bottleneck_analysis`, `resource_analysis`, `transition_matrix`, `timeline_visualization`, `rework_detection` |
| `bl.quality` | `data_profile`, `completeness_report`, `consistency_check`, `outlier_summary`, `uniqueness_analysis` |
| `bl.describe()` | Smart all-in-one data exploration with quality, stats, and distribution |

---

## 💡 Quick Examples

```python
import bizlens as bl
import pandas as pd

# Load a built-in teaching dataset (returns pandas DataFrame)
df = bl.load_dataset('titanic')   # or 'tips', 'iris', 'penguins', 'diamonds', 'mpg'

# Smart all-in-one description
bl.describe(df)

# Frequency distribution
bl.tables.frequency_table(df['sex'])

# Summary statistics
bl.tables.summary_statistics(df[['age', 'fare']])

# Contingency table with chi-square and Cramér's V
table, stats = bl.tables.contingency_table(df, 'sex', 'survived')
print(f"Chi² = {stats['chi2']:.3f}, p = {stats['p_value']:.4f}, Cramér's V = {stats['cramers_v']:.3f}")

# Data quality profile
bl.quality.data_profile(df)

# Confidence interval
bl.inference.confidence_interval(df['age'].dropna(), confidence=0.95)

# Two-sample t-test with effect size
bl.inference.two_sample_ttest(df[df['sex']=='male']['fare'], df[df['sex']=='female']['fare'])

# Outlier detection
bl.diagnostic.detect_outliers(df, 'fare')
```

### Process Mining

```python
# Generate a built-in event log
event_log = bl.generate_hr_onboarding_event_log()   # 500 cases, HR workflow
# event_log = bl.generate_healthcare_event_log()     # patient pathways
# event_log = bl.generate_manufacturing_event_log()  # production orders
# event_log = bl.generate_tech_support_event_log()   # IT ticket lifecycle

bl.process_mining.case_metrics(event_log)
bl.process_mining.bottleneck_analysis(event_log)
bl.process_mining.variant_discovery(event_log)
bl.process_mining.resource_analysis(event_log, resource_col='resource')
bl.process_mining.transition_matrix(event_log)
bl.process_mining.timeline_visualization(event_log)  # saves interactive HTML
```

### Polars Support

```python
# BizLens accepts both pandas and polars DataFrames transparently
import polars as pl
df_pl = pl.from_pandas(bl.load_dataset('titanic'))
bl.tables.frequency_table(df_pl['sex'])
bl.quality.data_profile(df_pl)
```

### Performance Profiling

```python
# Enable timing on every function call
bl.set_profiling(True)
bl.describe(df)   # shows execution time for each step
bl.set_profiling(False)
```

---

## 🔄 Supported Environments

| Environment | Status |
|------------|--------|
| Google Colab | ✅ Recommended |
| Jupyter Notebook / JupyterLab | ✅ Full |
| VS Code (Jupyter extension) | ✅ Full |
| Terminal / scripts | ✅ Full |
| Polars DataFrames | ✅ Transparent support |

---

## 📊 Version History

| Version | Key Changes |
|---------|------------|
| **2.2.15** | Fixed `bl.describe()`, `transition_matrix`, `timeline_visualization`, `summary_statistics`; beautiful chart theme in all notebooks |
| 2.2.14 | Quality import fix, version alignment |
| 2.2.13 | Polars support, profiling flag |

- **Current**: 2.2.15
- **Python**: 3.9+
- **License**: MIT

---

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/solutiongate-learn/bizlens/issues)
- **Discussions**: [GitHub Discussions](https://github.com/solutiongate-learn/bizlens/discussions)
- **PyPI**: [pypi.org/project/bizlens](https://pypi.org/project/bizlens/)

---

**Made with ❤️ for business analysts, data scientists, and educators**
